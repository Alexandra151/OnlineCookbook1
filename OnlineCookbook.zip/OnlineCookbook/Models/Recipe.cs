﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OnlineCookbook.Models
{
    public class Recipe
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Title { get; set; }

        public string Description { get; set; }

        public string Ingredients { get; set; }

        [Range(0, 5)]
        [Column(TypeName = "decimal(2, 1)")]
        public decimal Rating { get; set; }

        public int? CategoryId { get; set; }
        public Category Category { get; set; }

        public ICollection<RecipeIngredient> RecipeIngredients { get; set; }
    }
}